<?php

	include 'database.php';
	$nia = $_GET['nia'];
	//$nombre = $_GET['nombre'];
	$codnota = $_GET['codnota'];
	$fecha = $_GET['fecha'];
	$coment = $_GET['coment'];
	$tipo = $_GET['tipo'];
	
	date_default_timezone_set('utc');
	

	$database=open_database();

	$result = execute_query("insert into notasp (nia,codnota,fecha,coment,tipo) values ('$nia','$codnota','$fecha','$coment','$tipo')");

	echo json_encode ($result);


?>