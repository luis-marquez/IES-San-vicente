<?php

include 'database.php';

$grupo = $_GET['grupo'];

$documento = $_GET['documento'];

$database=open_database();

$result=execute_query("select * 
from horarios_grupo
where docente='$documento'
and grupo='$grupo'

");

echo json_encode ($result)


?>