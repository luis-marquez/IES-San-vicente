<?php

include 'database.php';

$grupo = $_GET['grupo'];

$database=open_database();

$result=execute_query("select * from coment,alumnos where coment.nia in 
(select alumnos.nia from alumnos where alumnos.grupo='$grupo')");

echo json_encode ($result)

?>