<?php

include 'database.php';

$grupo = $_GET['grupo'];

$database=open_database();

$result=execute_query("select alumnos.nombre nombre,alumnos.nia nia, alumnos.apellido1 apellido1, alumnos.apellido2 apellido2, grupos.nombre grupo 
from alumnos,grupos where alumnos.grupo='$grupo' and alumnos.grupo=grupos.codigo");

echo json_encode ($result)


?>