<?php

   include 'database.php';
   
   $clave = $_GET['clave'];
   
   $database = open_database();
   
   execute_query("delete from coment where clave='$clave'");
  
   close_database($database);

?>