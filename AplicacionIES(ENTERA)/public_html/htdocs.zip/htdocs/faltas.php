<?php
		include 'database.php';
		$dni = $_REQUEST["dni"];
		$fecha = $_REQUEST["fecha"];
		$horad = $_REQUEST["horad"];
		$horah = $_REQUEST["horah"];
		$dejatrab = $_REQUEST["dejatrab"];
		$comentsalum = $_REQUEST["comentsalum"];
		$coments = $_REQUEST["coments"];
		$motivo = $_REQUEST["motivo"];
		
                
                print_r($_REQUEST);
		
		$database = open_database();
		$result =execute_query ("INSERT INTO faltasprof (dni,fecha,horad,horah,dejatrab,coments,comentsalum,motivo) VALUES ('$dni','$fecha','$horad','$horah','$dejatrab','$coments','$comentsalum','$motivo')");
		echo json_encode ("OK");
		close_database ($database);
?>		