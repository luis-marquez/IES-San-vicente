<?php

   include 'database.php';
   
   $nia = $_GET['nia'];
   $coment = $_GET['coment'];
   $contenido = $_GET['contenido'];
   $codprof = $_GET['documento'];
   
   $database = open_database();
   
   execute_query("insert into coment (nia,coment,contenido,codprof) values('$nia','$coment','$contenido','$codprof')");
  
   close_database($database);

?>