starter.controller('ComentarioMenuCtrl', function($scope,$http) {

	/*$http.get("http://localhost/ver_grupos.php").success(function(data){
		$scope.grupos=data;
	});*/

});

