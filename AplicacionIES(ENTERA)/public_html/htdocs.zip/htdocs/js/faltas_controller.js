starter.controller('faltasCtrl', function($scope) {
});

