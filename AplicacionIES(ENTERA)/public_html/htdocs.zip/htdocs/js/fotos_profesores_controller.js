starter.controller('FotosProfesoresCtrl', function($scope, $stateParams, $http, $ionicPopup ) {
    $scope.grupo = $stateParams.grupo;

	
	$http.get("http://localhost/fotos_profesores.php?grupo="+$scope.grupo).success(function(data){
		$scope.profesores=data;
	});
	   
});
