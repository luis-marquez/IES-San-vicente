starter.controller('horadCtrl', function($scope,$stateParams) {
	$scope.documento = $stateParams.documento;
	$scope.horad = $stateParams.horad;
});