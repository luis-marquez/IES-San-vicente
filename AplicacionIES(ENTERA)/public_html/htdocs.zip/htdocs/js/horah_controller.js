starter.controller('horahCtrl', function($scope,$stateParams) {
	$scope.documento = $stateParams.documento;
	$scope.horad = $stateParams.horad;
	$scope.horah = $stateParams.horah;
});