starter.controller('selecprofCtrl', function($scope, $stateParams, $http) {

    $scope.documento = $stateParams.documento;
	
	$http.get("http://localhost/listadocentes.php").success(function(data){
		$scope.docentes=data;
	});
	   
});
