starter.controller('TodosAlumnosCtrl', function($scope, $stateParams, $http, $ionicPopup) {

    $scope.opcion = $stateParams.opcion;
    $scope.profesor = $stateParams.documento;
	
	
	$scope.PopUp = function(clave) {
	 var confirmPopup = $ionicPopup.confirm({
	   title: '¿Estas seguro?',
	   template: 'Si presiona OK el comentario seleccionado se borrará permanentemenete'
	 });
	 confirmPopup.then(function(res) {
	   if(res) {
			$http.get("http://localhost/eliminar_coment.php?clave="+clave).success(function(data){
				$http.get("http://localhost/ver_comentarios.php?nia="+$scope.nia).success(function(data){
					$scope.comentario_eliminar=data;
				});				
			});
		} else {
			console.log('You are not sure');
		}
	 });
	};

	
	$http.get("http://localhost/fotografias_alumnos.php?num=10000187").success(function(data){
		$scope.imagen=data;
	});	
	
	$http.get("http://localhost/todos_alumnos.php?documento="+$scope.profesor).success(function(data){
		$scope.alumnos=data;
	});
});
