starter.controller('verfaltasCtrl', function($scope, $http) {
    $http.get("http://localhost/verfaltas.php").success(function(data){
	$scope.faltas=data;
	})
});
