<?php
		include 'database.php';
		$database = open_database();
		$result = execute_query ("SELECT * FROM docentes");
		echo json_encode ($result);
		close_database ($database);
?>		