<?php

	include 'database.php';
	$nia = $_GET['nia'];

	
	date_default_timezone_set('utc');
	

	$database=open_database();

	$result = execute_query("select * from notasp where nia='$nia'");

	echo json_encode ($result);


?>