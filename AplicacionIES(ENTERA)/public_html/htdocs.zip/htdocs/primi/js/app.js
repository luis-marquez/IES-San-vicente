var starter = angular.module('starter.controllers', []);

angular.module('starter', ['ionic', 'starter.controllers'])

.run(function($ionicPlatform) {
    $ionicPlatform.ready(function() {
    });
})

.config(function($stateProvider, $urlRouterProvider) {

    $stateProvider

    .state('reservas', {
        url: "/reservas",
        templateUrl: "templates/reservas.html",
        controller: 'reservasCtrl'
    })

    .state('reservas_fecha', {
        url: "/reservas_fecha",
        templateUrl: "templates/reservas_fecha.html",
        controller: 'reservas_fechaCtrl'
    })
	
	.state('reserva_horah', {
        url: "/reserva_horah/:fecha",
        templateUrl: "templates/reserva_horah.html",
        controller: 'reserva_horahCtrl'
    })
	
	.state('reserva_horad', {
        url: "/reserva_horad/:fecha/:horad/",
        templateUrl: "templates/reserva_horad.html",
        controller: 'reserva_horadCtrl'
    })
	
	.state('reserva_aula', {
        url: "/reserva_aula/:fecha/:horad/:horah/",
        templateUrl: "templates/reserva_aula.html",
        controller: 'reserva_aulaCtrl'
    })
	
	.state('reserva_curso', {
        url: "/reservas_curso/:fecha/:horad/:horah/:aula/:aulacodigo",
        templateUrl: "templates/reservas_curso.html",
        controller: 'reserva_cursoCtrl'
    })
	
	.state('reserva_grupo', {
        url: "/reserva_grupo/:fecha/:horad/:horah/:aula/:aulacodigo/:curso/:cursocodigo",
        templateUrl: "templates/reserva_grupo.html",
        controller: 'reserva_grupoCtrl'
    })
	
	.state('reserva_asignatura', {
        url: "/reservas_asignatura/:fecha/:horad/:horah/:aula/:aulacodigo/:curso/:cursocodigo/:grupo/:grupocodigo",
        templateUrl: "templates/reservas_asignatura.html",
        controller: 'reservas_asignaturasCtrl'
    })
	
	.state('reserva_formulario', {
        url: "/reserva_formulario/:fecha/:horad/:horah/:aula/:aulacodigo/:curso/:cursocodigo/:grupo/:grupocodigo/:asignatura/:asignaturacodigo",
        templateUrl: "templates/reserva_formulario.html",
        controller: 'reserva_formularioCtrl'
    })
	
	.state('reservas_quitar', {
        url: "/reservas_quitar",
        templateUrl: "templates/reservas_quitar.html",
        controller: 'reservas_quitarCtrl'
    })

	.state('reservas_listar', {
        url: "/reservas_listar",
        templateUrl: "templates/reservas_listar.html",
        controller: 'reservas_listarCtrl'
    });
	
    $urlRouterProvider.otherwise('/reservas');

});