starter.controller('reserva_horadCtrl', function($scope, $stateParams) {
	$scope.fecha = $stateParams.fecha;
	$scope.horad = $stateParams.horad;
	$scope.horah = $stateParams.horah;
});