starter.controller('reserva_horahCtrl', function($scope, $stateParams) {
	$scope.fecha = $stateParams.fecha;
	$scope.horad = $stateParams.horad;
});
