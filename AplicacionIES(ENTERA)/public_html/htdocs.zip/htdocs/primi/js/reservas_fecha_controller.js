starter.controller('reservas_fechaCtrl', function($scope, $stateParams) {
	$scope.fecha = $stateParams.fecha;
});