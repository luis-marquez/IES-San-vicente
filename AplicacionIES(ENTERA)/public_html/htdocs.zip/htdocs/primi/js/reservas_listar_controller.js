starter.controller('reservas_listarCtrl', function($scope, $stateParams, $http) {
	$http.get("http://aprimi.iessv.es/lista_reservas.php").success(function(data){
		$scope.reservas=data;
	});	
});