starter.controller('reservas_quitarCtrl', function($scope, $stateParams, $http, $ionicPopup) {

	$http.get("http://aprimi.iessv.es/lista_reservas.php").success(function(data){
		$scope.reservas=data;
	});
	


});