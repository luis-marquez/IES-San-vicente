var starter = angular.module('starter.controllers', []);

angular.module('starter', ['ionic', 'starter.controllers'])

.run(function($ionicPlatform) {
    $ionicPlatform.ready(function() {
    });
})

.config(function($stateProvider, $urlRouterProvider) {

    $stateProvider

    .state('faltas', {
        url: "/faltas",
        templateUrl: "templates/faltas.html",
        controller: 'faltasCtrl'
    })

    	
	.state('verfaltas', {
        url: "/verfaltas",
        templateUrl: "templates/verfaltas.html",
        controller: 'verfaltasCtrl'
    })
	
	.state('borrarfaltas', {
        url: "/borrarfaltas",
        templateUrl: "templates/borrarfaltas.html",
        controller: 'borrarCtrl'
    })
	
	.state('selecprof', {
        url: "/selecprof",
        templateUrl: "templates/selecprof.html",
        controller: 'selecprofCtrl'
    })
	
	.state('horad', {
        url: "/horad/:documento",
        templateUrl: "templates/horad.html",
        controller: 'horadCtrl'
    })
	
	.state('horah', {
        url: "/horah/:documento/:horad/",
        templateUrl: "templates/horah.html",
        controller: 'horahCtrl'
    })
	
	.state('trabajo', {
        url: "/trabajo/:documento/:horad/:horah/",
        templateUrl: "templates/trabajo.html",
        controller: 'trabajoCtrl'
    })
			
	.state('fecha', {
        url: "/fecha/:documento/:horad/:horah/:trab/",
        templateUrl: "templates/fecha.html",
        controller: 'fechaCtrl'
    })

	.state('motivo', {
        url: "/motivo/:documento/:horad/:horah/:trab/:fecha/",
        templateUrl: "templates/motivo.html",
        controller: 'motivoCtrl'
    })
	
	.state('resumen', {
        url: "/resumen/:documento/:horad/:horah/:trab/:fecha/:motivo/",
        templateUrl: "templates/resumen.html",
        controller: 'resumenCtrl'
    })
	
	
    $urlRouterProvider.otherwise('/faltas');

});





















