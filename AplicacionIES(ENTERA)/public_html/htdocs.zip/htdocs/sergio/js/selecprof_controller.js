starter.controller('selecprofCtrl', function($scope,$http,$stateParams) {
	$scope.documento = $stateParams.documento;
	$http.get("http://localhost/app/listadocentes.php").success(function(data){
	$scope.docentes=data;
	})
});

