starter.controller('verfaltasCtrl', function($scope, $http) {
    $http.get("http://localhost/app/verfaltas.php").success(function(data){
	$scope.faltas=data;
	})
});
