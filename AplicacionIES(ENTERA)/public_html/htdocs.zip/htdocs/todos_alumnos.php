<?php

include 'database.php';

$documento = $_GET['documento'];

$database=open_database();

$result=execute_query("select alumnos.nombre,alumnos.apellido1,alumnos.apellido2, alumnos.curso, alumnos.grupo from alumnos,horarios_grupo
where horarios_grupo.docente='$documento'
and alumnos.curso=horarios_grupo.curso
and alumnos.grupo=horarios_grupo.grupo
and horarios_grupo.ensenanza=alumnos.ensenanza");

echo json_encode ($result)


?>