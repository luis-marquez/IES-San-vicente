<?php

include 'database.php';

$nia = $_GET['nia'];

$database=open_database();

$result=execute_query("select * from coment where nia='$nia'");

echo json_encode ($result)

?>