<?php
		include 'database.php';
		$database = open_database();
		$result = execute_query ("SELECT * FROM faltasprof, docentes where docentes.documento=faltasprof.dni");
		echo json_encode ($result);
		close_database ($database);
?>